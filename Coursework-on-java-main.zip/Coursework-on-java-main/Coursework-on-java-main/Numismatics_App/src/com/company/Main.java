package com.company;

import org.jsoup.Jsoup;


import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.xml.sax.SAXException;
import org.jsoup.nodes.Document;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.*;

import java.net.URL;
import java.net.URLConnection;

import java.util.ArrayList;
import java.util.Scanner;



public class Main {

    private static String country = "germany";

    public static void main(String[] args) throws IOException, ParserConfigurationException, SAXException {





        //Scanner scanCountry = new Scanner(System.in);
        //System.out.println("Enter country");
       // String country = scanCountry.nextLine();

        Collection collection = new Collection("Croatia");
        ArrayList<String> titles = new ArrayList<>();
        Document doc = Jsoup.connect("https://en.ucoin.net/catalog/?country=croatia").get();
        Elements title = doc.getElementsByAttributeValue("class","value");

       // title.forEach(text->System.out.println(text));


        /*title.forEach(scope->{

            // Element rty = scope.child(0);

            
            String rwer=scope.text();

            System.out.println();

            System.out.println(rwer);
            System.out.println();System.out.println();


        });*/













    }

    public void createCoin(String country,String currency,String value,String category,Float costActual,String linkUcoin){

    Coin coin = new Coin();

    coin.setCountry(country);
    coin.setCurrency(currency);
    coin.setValue(value);
    coin.setCategory(category);
    coin.setCostActual(costActual);
    coin.setLinkUcoin(linkUcoin);

    };

    public void addCoinToCollection(Collection collection,Coin coin){

        collection.addToCollection(coin);

    };
}
