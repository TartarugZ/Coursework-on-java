package com.company;

public class Coin {

    private  String country;
    private  String currency;
    private  String value;
    private  String category;
    private Float costActual;
    private Float costOld;
    private String linkUcoin;

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public Float getCostActual() {
        return costActual;
    }

    public void setCostActual(Float costActual) {
        this.costActual = costActual;
    }

    public Float getCostOld() {
        return costOld;
    }

    public void setCostOld(Float costOld) {
        this.costOld = costOld;
    }

    public String getLinkUcoin() {
        return linkUcoin;
    }

    public void setLinkUcoin(String linkUcoin) {
        this.linkUcoin = linkUcoin;
    }
}
